const getBoard = (value: number) => {
    let board = '';
    let total = 0;
    for (let i = 0; i < value; i++) {
        for (let k = 0; k < value; k++) {
            if (total % 2 === 0) {
                board += '  ';
            } else {
                board += '██';
            }
            total++;
        }
        board += '\n';
        total++
    }
    console.log(board);
};

getBoard(8);